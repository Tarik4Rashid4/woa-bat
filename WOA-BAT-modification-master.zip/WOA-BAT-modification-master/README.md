
# WOA-BAT-modification
Cite as:

Hardi M. Mohammed, Shahla U. Umar, and Tarik A. Rashid (2019). A Systematic and Meta-Analysis Survey of Whale Optimization Algorithm, Computational Intelligence and Neuroscience, vol. 2019, Article ID 8718571, 25 pages. https://doi.org/10.1155/2019/8718571.

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

WOA-BAT modification is an improvement in Whale Optimization Algorithm which includes the hybridization of WOA and BAT algorithms, the results  shows that WOA-BAT is better than WOA in cec2005, cec2019 and 23 benchmark functions.
% the paper is entitled "A Systematic and Meta-analysis Survey of Whale Optimization
Algorithm" has been accepted by Computational Intelligence and Neuroscience Journal 

%_________________________________________________________________________%
% WOA-BAT modification  source codes   by                                 %
% Hardi M. Mohammed , Shahla U. Umar, Tarik A. Rashid                     %
%                                                                         %
%                                                                         %
%  we improved the code of WOA which have been written by mirjalili       %
%      then we hybridize BAT algorithm with WOA.                          %
%_________________________________________________________________________%
